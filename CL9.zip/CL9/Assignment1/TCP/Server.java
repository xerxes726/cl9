// Java program to illustrate Server Side Programming
// for banking using TCP
//43138
//R9
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;
import java.lang.Math;

public class Server
{
	public static void main(String args[]) throws IOException
	{

		// Step 1: Establish the socket connection.
		ServerSocket ss = new ServerSocket(4444);
		Socket s = ss.accept();

		// Step 2: Processing the request.
		DataInputStream dis = new DataInputStream(s.getInputStream());
		DataOutputStream dos = new DataOutputStream(s.getOutputStream());

		while (true)
		{
			// wait for input
			String input = dis.readUTF();

			if(input.equals("exit"))
				break;
			double result;
			System.out.println("Bank Account number:-" + input);
			result = Math.random()*10000;	
			System.out.println("Sending the result...");

			// send the result back to the client.
			dos.writeUTF(Double.toString(result));
		}
	}
}

